/* HEIC → JPG converter — 100% client-side.
   Decodes + encodes in a pool of Web Workers (one per CPU core, each running
   libheif + OffscreenCanvas), then bundles a ZIP with JSZip.
   No network requests are made with the user's images. */
(function () {
  "use strict";

  const $ = (id) => document.getElementById(id);
  const dropzone = $("dropzone");
  const fileInput = $("fileInput");
  const controls = $("controls");
  const convertBtn = $("convertBtn");
  const downloadBtn = $("downloadBtn");
  const clearBtn = $("clearBtn");
  const quality = $("quality");
  const qualityOut = $("qualityOut");
  const fileList = $("fileList");
  const progressWrap = $("progressWrap");
  const progressFill = $("progressFill");
  const progressText = $("progressText");

  /** @type {{file:File, status:string, jpgBlob:Blob|null, jpgName:string|null, error:string|null, el:HTMLElement}[]} */
  let items = [];
  let busy = false;

  const HEIC_RE = /\.(heic|heif)$/i;
  const isHeic = (f) =>
    HEIC_RE.test(f.name) || f.type === "image/heic" || f.type === "image/heif";

  function fmtSize(bytes) {
    if (bytes < 1024) return bytes + " B";
    if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(0) + " KB";
    return (bytes / 1024 / 1024).toFixed(1) + " MB";
  }

  function jpgName(name) {
    return name.replace(/\.[^.]+$/, "") + ".jpg";
  }

  function uniqueName(name, used) {
    let candidate = name, n = 1;
    const base = name.replace(/\.jpg$/i, "");
    while (used.has(candidate.toLowerCase())) candidate = `${base} (${n++}).jpg`;
    used.add(candidate.toLowerCase());
    return candidate;
  }

  function renderItem(it) {
    const li = document.createElement("li");
    li.className = "file-item";
    li.innerHTML =
      `<span class="name"></span>` +
      `<span class="size"></span>` +
      `<span class="badge pending">queued</span>`;
    li.querySelector(".name").textContent = it.file.name;
    li.querySelector(".size").textContent = fmtSize(it.file.size);
    fileList.appendChild(li);
    it.el = li;
  }

  function setStatus(it, status, extra) {
    it.status = status;
    const badge = it.el.querySelector(".badge");
    badge.className = "badge " + status;
    badge.textContent =
      status === "pending" ? "queued" :
      status === "converting" ? "converting…" :
      status === "done" ? "done" : "error";
    if (status === "error" && extra) {
      badge.textContent = "error";
      badge.title = extra;
    }
    if (status === "done" && it.jpgBlob) {
      const a = document.createElement("a");
      a.className = "dl";
      a.textContent = "save jpg";
      a.href = URL.createObjectURL(it.jpgBlob);
      a.download = it.jpgName;
      it.el.insertBefore(a, badge);
    }
  }

  function addFiles(fileListLike) {
    const incoming = Array.from(fileListLike);
    const heics = incoming.filter(isHeic);
    const skipped = incoming.length - heics.length;
    for (const f of heics) {
      const it = { file: f, status: "pending", jpgBlob: null, jpgName: null, error: null, el: null };
      items.push(it);
      renderItem(it);
    }
    if (skipped > 0) {
      progressWrap.hidden = false;
      progressText.textContent = `Skipped ${skipped} non-HEIC file${skipped > 1 ? "s" : ""}.`;
      progressFill.style.width = "0%";
    }
    syncUI();
  }

  function syncUI() {
    const hasItems = items.length > 0;
    controls.hidden = !hasItems;
    const pending = items.some((it) => it.status === "pending");
    convertBtn.disabled = busy || !pending;
    const anyDone = items.some((it) => it.status === "done");
    downloadBtn.hidden = !anyDone || busy;
  }

  const MAX_WORKERS = 8;

  function poolSize(n) {
    const hw = navigator.hardwareConcurrency || 4;
    return Math.max(1, Math.min(hw, n, MAX_WORKERS));
  }

  // One conversion request → response on a dedicated worker (serial per worker,
  // so a plain onmessage handler is safe). Transfers buffers both ways.
  function convertOnce(worker, buffer, q) {
    return new Promise((resolve, reject) => {
      worker.onmessage = (e) =>
        e.data.ok ? resolve(e.data.buffer) : reject(new Error(e.data.error));
      worker.onerror = (e) => reject(new Error(e.message || "worker crashed"));
      worker.postMessage({ buffer, quality: q }, [buffer]);
    });
  }

  async function convertAll() {
    if (busy) return;
    if (typeof Worker === "undefined" || typeof OffscreenCanvas === "undefined") {
      progressWrap.hidden = false;
      progressText.textContent =
        "This browser is too old — it lacks Web Worker / OffscreenCanvas support.";
      return;
    }
    busy = true;
    downloadBtn.hidden = true;
    progressWrap.hidden = false;
    syncUI();

    const q = parseInt(quality.value, 10) / 100;
    const todo = items.filter((it) => it.status === "pending" || it.status === "error");
    const usedNames = new Set(
      items.filter((it) => it.status === "done").map((it) => it.jpgName.toLowerCase())
    );
    const total = todo.length;
    const size = poolSize(total);
    let completed = 0;
    let next = 0;

    progressText.textContent = `Converting 0 of ${total} across ${size} worker${size !== 1 ? "s" : ""}…`;
    progressFill.style.width = "0%";

    const workers = Array.from({ length: size }, () =>
      new Worker("convert-worker.js", { type: "module" })
    );

    // Each worker pulls the next queued file until the queue drains.
    async function drain(worker) {
      while (true) {
        const i = next++;
        if (i >= total) break;
        const it = todo[i];
        setStatus(it, "converting");
        try {
          const buf = await it.file.arrayBuffer();
          const outBuf = await convertOnce(worker, buf, q);
          it.jpgBlob = new Blob([outBuf], { type: "image/jpeg" });
          it.jpgName = uniqueName(jpgName(it.file.name), usedNames);
          setStatus(it, "done");
        } catch (err) {
          it.error = (err && err.message) || String(err);
          setStatus(it, "error", it.error);
        }
        completed++;
        progressText.textContent = `Converting ${completed} of ${total} across ${size} worker${size !== 1 ? "s" : ""}…`;
        progressFill.style.width = Math.round((completed / total) * 100) + "%";
      }
    }

    await Promise.all(workers.map(drain));
    workers.forEach((w) => w.terminate());

    const okCount = items.filter((it) => it.status === "done").length;
    const errCount = items.filter((it) => it.status === "error").length;
    progressText.textContent =
      `Converted ${okCount} file${okCount !== 1 ? "s" : ""}` +
      (errCount ? `, ${errCount} failed` : "") +
      ` using ${size} parallel worker${size !== 1 ? "s" : ""}.`;
    busy = false;
    syncUI();
  }

  async function downloadZip() {
    const done = items.filter((it) => it.status === "done" && it.jpgBlob);
    if (!done.length) return;
    downloadBtn.disabled = true;
    progressText.textContent = "Building ZIP…";
    const zip = new JSZip();
    for (const it of done) zip.file(it.jpgName, it.jpgBlob);
    const blob = await zip.generateAsync(
      { type: "blob", compression: "STORE" }, // JPGs are already compressed
      (meta) => { progressFill.style.width = Math.round(meta.percent) + "%"; }
    );
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "heic-to-jpg.zip";
    document.body.appendChild(a);
    a.click();
    a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 4000);
    progressText.textContent = `ZIP ready — ${done.length} image${done.length !== 1 ? "s" : ""}, ${fmtSize(blob.size)}.`;
    downloadBtn.disabled = false;
  }

  function clearAll() {
    if (busy) return;
    items.forEach((it) => {
      const a = it.el && it.el.querySelector("a.dl");
      if (a) URL.revokeObjectURL(a.href);
    });
    items = [];
    fileList.innerHTML = "";
    progressWrap.hidden = true;
    progressFill.style.width = "0%";
    progressText.textContent = "";
    syncUI();
  }

  // --- wiring ---
  dropzone.addEventListener("click", () => fileInput.click());
  dropzone.addEventListener("keydown", (e) => {
    if (e.key === "Enter" || e.key === " ") { e.preventDefault(); fileInput.click(); }
  });
  fileInput.addEventListener("change", (e) => { addFiles(e.target.files); fileInput.value = ""; });

  ["dragenter", "dragover"].forEach((ev) =>
    dropzone.addEventListener(ev, (e) => { e.preventDefault(); dropzone.classList.add("dragover"); })
  );
  ["dragleave", "drop"].forEach((ev) =>
    dropzone.addEventListener(ev, (e) => { e.preventDefault(); dropzone.classList.remove("dragover"); })
  );
  dropzone.addEventListener("drop", (e) => {
    if (e.dataTransfer && e.dataTransfer.files) addFiles(e.dataTransfer.files);
  });

  quality.addEventListener("input", () => { qualityOut.textContent = quality.value; });
  convertBtn.addEventListener("click", convertAll);
  downloadBtn.addEventListener("click", downloadZip);
  clearBtn.addEventListener("click", clearAll);

  // Prevent the browser from navigating away when a file is dropped outside the zone.
  window.addEventListener("dragover", (e) => e.preventDefault());
  window.addEventListener("drop", (e) => e.preventDefault());
})();
