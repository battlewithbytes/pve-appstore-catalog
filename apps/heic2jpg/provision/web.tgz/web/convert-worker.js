/* Module worker: decode one HEIC buffer with libheif and encode JPEG via
   OffscreenCanvas — all off the main thread. One of these runs per CPU core. */
import buildLibheif from "./vendor/libheif.js";

// libheif here is built with WASM=0 (asm.js), so it initializes synchronously.
const libheif = buildLibheif();

async function decodeToImageData(buffer) {
  let decoder, data;
  try {
    decoder = new libheif.HeifDecoder();
    data = decoder.decode(buffer);
    if (!data || !data.length) throw new Error("No image found in HEIF file");

    const image = data[0];
    const width = image.get_width();
    const height = image.get_height();

    // Pre-fill alpha to opaque (libheif fills RGB during display()).
    const out = new ImageData(width, height);
    for (let i = 0; i < width * height; i++) out.data[i * 4 + 3] = 255;

    return await new Promise((resolve, reject) => {
      image.display(out, (displayData) => {
        if (!displayData) return reject(new Error("HEIF processing error"));
        resolve(displayData);
      });
    });
  } finally {
    if (data && data.length) for (let i = 0; i < data.length; i++) data[i].free();
    if (decoder && decoder.decoder) libheif.heif_context_free(decoder.decoder);
  }
}

self.onmessage = async (e) => {
  const { quality } = e.data;
  const buffer = e.data.buffer;
  try {
    const imageData = await decodeToImageData(buffer);
    const canvas = new OffscreenCanvas(imageData.width, imageData.height);
    const ctx = canvas.getContext("2d");
    ctx.putImageData(imageData, 0, 0);
    const blob = await canvas.convertToBlob({ type: "image/jpeg", quality });
    const outBuf = await blob.arrayBuffer();
    self.postMessage({ ok: true, buffer: outBuf }, [outBuf]);
  } catch (err) {
    self.postMessage({ ok: false, error: (err && err.message) || String(err) });
  }
};
